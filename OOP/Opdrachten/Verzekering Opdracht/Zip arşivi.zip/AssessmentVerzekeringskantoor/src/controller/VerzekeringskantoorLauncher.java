package controller;

import model.Auto;
import java.util.ArrayList;
import java.util.List;

public class VerzekeringskantoorLauncher {

    public static void main(String[] args) {
        // Lijst met Auto"s maken voor AutoPolissen
        List<Auto> autoLijst = new ArrayList<>();
        autoLijst.add(new Auto("7-THT-78","Toyota","hybrid"));
        autoLijst.add(new Auto("70-HN-KL","Renault","benzine"));
        autoLijst.add(new Auto("GP-GL-46","Mercedes", "diesel"));
        autoLijst.add(new Auto("RX-462-G","Tesla","electrisch"));
        autoLijst.add(new Auto("25-ZK-FK","Dacia","benzine"));
        autoLijst.add(new Auto("34-XL-KG","Skoda","diesel"));
        autoLijst.add(new Auto("56-HFZ-2","Mitsubishi","hybrid"));
        autoLijst.add(new Auto("TP-639-X","Tesla","electrisch"));
        autoLijst.add(new Auto("ST-857-F","Renault","electrisch"));
    }
}
